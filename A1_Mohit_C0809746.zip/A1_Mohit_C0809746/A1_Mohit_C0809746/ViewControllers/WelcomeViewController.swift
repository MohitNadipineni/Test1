//
//  WelcomeViewController.swift
//  MapProject2
//
//  Created by Mohit
//

import UIKit

class WelcomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.barTintColor = UIColor.black
        self.navigationController?.navigationBar.tintColor = UIColor.green
        self.navigationController?.navigationBar.titleTextAttributes = [.foregroundColor:UIColor.green]
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    @IBAction func btnClicked(_ sender : UIButton){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "RouteMapController") as! RouteMapController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
}
