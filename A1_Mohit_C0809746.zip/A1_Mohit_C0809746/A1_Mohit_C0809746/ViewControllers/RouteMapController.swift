//
//  RouteMapController.swift
//  MapProject2
//
//  Created by Mohit
//

import UIKit
import MapKit

class RouteMapController: UIViewController,MKMapViewDelegate {

    //MARK:- Outlets
    @IBOutlet weak var vwMap : MKMapView!
    @IBOutlet weak var directionButton : UIButton!
    
    //MARK:- Class Variables
    
    var annotationA : MKPointAnnotation!
    var annotationB : MKPointAnnotation!
    var annotationC : MKPointAnnotation!
    
    //MARK:- Custom Methods
    var lineColor = UIColor.green
    var fillColor = UIColor.red.withAlphaComponent(0.5)
    var lineWidth : CGFloat = 3.5
    
    func setUp(){
        self.title = "Map Route"
        
        //
        let gest = UILongPressGestureRecognizer(target: self, action: #selector(handleGest(_:)))
        gest.minimumPressDuration = 0.4
        vwMap.addGestureRecognizer(gest)
        // mapSetup
        //self.vwMap.showsUserLocation = true
        self.vwMap.delegate = self
        //zoom after delay
        self.perform(#selector(zoomToCurrentLocation), with: nil, afterDelay: 0.4)
        //
        self.directionButton.layer.cornerRadius = 25
        self.hideShowDirectionButton(true)
    }
   
    @objc func handleGest(_ gesture : UILongPressGestureRecognizer){
        
        guard gesture.state == .began else {return}
        
        let touchPoint:CGPoint = gesture.location(in: self.vwMap)
        let currentLocation:CLLocationCoordinate2D =
            self.vwMap.convert(touchPoint, toCoordinateFrom: self.vwMap)
        
        let diff = self.getDiffBetweenLocations(currentLocation, LocationHelper.sharedInstance.getUserLocation().coordinate)
        let miles = self.convertMeterToMile(diff)
        
        self.checkMarkerLocationBeforeAdd(currentLocation)
        
        if self.annotationA != nil && self.annotationB != nil && self.annotationC != nil{
            self.removeAnnotationsAndOverlays()
            self.hideShowDirectionButton(true)
        }
                
        if self.annotationA == nil{
            self.annotationA = self.addMarker(title: "A", distance: miles, location: currentLocation)
            self.vwMap.addAnnotation(self.annotationA)
        }else if self.annotationB == nil{
            self.annotationB = self.addMarker(title: "B", distance: miles, location: currentLocation)
            self.vwMap.addAnnotation(self.annotationB)
        }else if self.annotationC == nil{
            self.annotationC = self.addMarker(title: "C", distance: miles, location: currentLocation)
            self.vwMap.addAnnotation(self.annotationC)
        }
        
        if self.annotationA != nil && self.annotationB != nil && self.annotationC != nil{
            let coordinates = [self.annotationA.coordinate,self.annotationB.coordinate,self.annotationC.coordinate]
            self.createTriangle(coordinates)
            self.hideShowDirectionButton(false)
        }
        
    }
    
    @objc func zoomToCurrentLocation(){
        let region  = MKCoordinateRegion(center: LocationHelper.sharedInstance.getUserLocation().coordinate, latitudinalMeters: 700, longitudinalMeters: 700)
        self.vwMap.setRegion(region, animated: true)
    }
    
    func createTriangle(_ coordinates:[CLLocationCoordinate2D]){
        self.vwMap.removeOverlays(self.vwMap.overlays)
        let overlay = MKPolygon(coordinates: coordinates, count: coordinates.count)
        vwMap.addOverlay(overlay)
    }
    
    func addMarker(title:String,distance:String,location:CLLocationCoordinate2D) -> MKPointAnnotation{
        let annotation = MKPointAnnotation()
        annotation.title = "Annotation \(title)"
        annotation.subtitle = "Difference is \(distance) Miles"
        annotation.coordinate = location
        return annotation
    }
    
    func checkMarkerLocationBeforeAdd(_ location : CLLocationCoordinate2D){
        if let tempMarker  = self.annotationA{
            let distanceFromA = self.getDiffBetweenLocations(location, tempMarker.coordinate)
            if tempMarker.coordinate.isEqualTo(location) || distanceFromA <= 60{
                self.vwMap.removeAnnotation(tempMarker)
                self.annotationA = nil
                self.hideShowDirectionButton(true)
                self.removeAnnotationsAndOverlays()
                return
            }
        }
        
        if let marker  = self.annotationB{
            let distanceFromA = self.getDiffBetweenLocations(location, marker.coordinate)
            if marker.coordinate.isEqualTo(location) || distanceFromA <= 60{
                self.vwMap.removeAnnotation(marker)
                self.annotationB = nil
                self.hideShowDirectionButton(true)
                self.removeAnnotationsAndOverlays()
                return
            }
        }
        
        if let marker  = self.annotationC{
            let distanceFromA = self.getDiffBetweenLocations(location, marker.coordinate)
            if marker.coordinate.isEqualTo(location) || distanceFromA <= 60{
                self.vwMap.removeAnnotation(marker)
                self.annotationC = nil
                self.hideShowDirectionButton(true)
                self.removeAnnotationsAndOverlays()
                return
            }
        }
    }
    
    
    func getDiffBetweenLocations(_ location1 : CLLocationCoordinate2D,_ location2 : CLLocationCoordinate2D) -> Double{
        return CLLocation(latitude: location1.latitude, longitude: location1.longitude).distance(from: CLLocation(latitude: location2.latitude, longitude: location2.longitude))
    }
    
    func convertMeterToMile(_ meter:Double) -> String{
        let miles = meter / 1609
        return String(format: "%.2f", miles)
    }
    
    
    func removeAnnotationsAndOverlays(){
        self.removeOverlaysFromMap()
        self.annotationA = nil
        self.annotationB = nil
        self.annotationC = nil
        let annotations = self.vwMap.annotations
        self.vwMap.removeAnnotations(annotations)
    }
    
    func removeOverlaysFromMap(){
        let overlays = self.vwMap.overlays
        self.vwMap.removeOverlays(overlays)
    }
    
    func boundMapToOverlay(_ polygon : MKPolygon){
        vwMap.setRegion(MKCoordinateRegion(polygon.boundingMapRect), animated: true)
    }
    
    func hideShowDirectionButton(_ isHide : Bool){
        self.directionButton.isHidden = isHide
        self.directionButton.isHidden = isHide
    }
    
    func showDirection(){
        self.drawRouteFromAtoB()
        self.drawRouteFromBtoC()
        self.drawRouteFromCtoA()
    }
    
    
    func drawRouteFromAtoB(){
        let sourcePlacemark = MKPlacemark(coordinate: self.annotationA.coordinate)
        let destinationPlacemark = MKPlacemark(coordinate: self.annotationB.coordinate)
        //
        let sourceItem = MKMapItem(placemark: sourcePlacemark)
        let destinationItem = MKMapItem(placemark: destinationPlacemark)
        
        let reqest = MKDirections.Request()
        reqest.source = sourceItem
        reqest.destination = destinationItem
        reqest.transportType = .walking
        
        let direction = MKDirections(request: reqest)
        direction.calculate { (response, error) in
            guard let res = response else{
                if let err = error{
                    print("Error: \(err)")
                }
                return
            }
            if let route = res.routes.first{
                self.vwMap.addOverlay(route.polyline, level: .aboveRoads)
            }
        }
    }
    
    func drawRouteFromBtoC(){
        let sourcePlacemark = MKPlacemark(coordinate: self.annotationB.coordinate)
        let destinationPlacemark = MKPlacemark(coordinate: self.annotationC.coordinate)
        //
        let sourceItem = MKMapItem(placemark: sourcePlacemark)
        let destinationItem = MKMapItem(placemark: destinationPlacemark)
        
        let reqest = MKDirections.Request()
        reqest.source = sourceItem
        reqest.destination = destinationItem
        reqest.transportType = .walking
        
        let direction = MKDirections(request: reqest)
        direction.calculate { (response, error) in
            guard let res = response else{
                if let err = error{
                    print("Error: \(err)")
                }
                return
            }
            if let route = res.routes.first{
                self.vwMap.addOverlay(route.polyline, level: .aboveRoads)
            }
        }
    }
        
    func drawRouteFromCtoA(){
        let sourcePlacemark = MKPlacemark(coordinate: self.annotationC.coordinate)
        let destinationPlacemark = MKPlacemark(coordinate: self.annotationA.coordinate)
        //
        let sourceItem = MKMapItem(placemark: sourcePlacemark)
        let destinationItem = MKMapItem(placemark: destinationPlacemark)
        
        let reqest = MKDirections.Request()
        reqest.source = sourceItem
        reqest.destination = destinationItem
        reqest.transportType = .walking
        
        let direction = MKDirections(request: reqest)
        direction.calculate { (response, error) in
            guard let res = response else{
                if let err = error{
                    print("Error: \(err)")
                }
                return
            }
            if let route = res.routes.first{
                self.vwMap.addOverlay(route.polyline, level: .aboveRoads)
            }
        }
    }
    
    //MARK:- Click Events
    
    @IBAction func directionButtonClicked(_ sender : UIButton){
        self.removeOverlaysFromMap()
        self.showDirection()
        self.hideShowDirectionButton(true)
    }
    
    //MARK:- Deleagate Methods
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if overlay is MKPolygon{
            let polygonRendrer = MKPolygonRenderer(polygon: overlay as! MKPolygon)
            polygonRendrer.fillColor = self.fillColor
            polygonRendrer.strokeColor = self.lineColor
            polygonRendrer.lineWidth = self.lineWidth
            self.boundMapToOverlay(overlay as! MKPolygon)
            return polygonRendrer
        }else if overlay is MKPolyline{
            let polylineRendrer = MKPolylineRenderer(polyline: overlay as! MKPolyline)
            polylineRendrer.strokeColor = self.lineColor
            polylineRendrer.lineWidth = self.lineWidth
            return polylineRendrer
        }
        return MKOverlayRenderer()
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
     
        var vwAnnotation = vwMap.dequeueReusableAnnotationView(withIdentifier: "Annotation") as? MKPinAnnotationView
        if vwAnnotation == nil {
            vwAnnotation = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "Annotation")
            vwAnnotation?.canShowCallout = true
            vwAnnotation?.rightCalloutAccessoryView = UIButton(type: .infoDark)
        } else {
            vwAnnotation?.annotation = annotation
        }
        
        return vwAnnotation
    }
    
    
    //MARK:- Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUp()
    }

}



extension CLLocationCoordinate2D{
    
    func isEqualTo(_ coordinate:CLLocationCoordinate2D) -> Bool{
        return self.latitude == coordinate.latitude && self.longitude == coordinate.longitude
    }
    
}
