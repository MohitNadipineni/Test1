//
//  LocatioHelper.swift
//  MapProject2
//
//  Created by Mohit
//

import Foundation
import CoreLocation

class LocationHelper: NSObject , CLLocationManagerDelegate {
    
    
    
    
    var locationManager     : CLLocationManager = CLLocationManager()
    var presentLocation            : CLLocation = CLLocation()
    
    static let sharedInstance : LocationHelper = LocationHelper()
    
    //---------------------------------------------------------------------
    
    deinit {
        
    }
    
    override init() {
        super.init()
        self.setupInitialLocation()
    }
    
    
    
    //MARK: - Current Lat Long
    
    //TODO: To get location permission just call this method
    func setupInitialLocation() {
//        locationManager = CLLocationManager()
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    //TODO: To get permission is allowed or declined
    func checkStatus() -> CLAuthorizationStatus{
        return CLLocationManager.authorizationStatus()
    }
    
    //TODO: To get user's current location
    func getUserLocation() -> CLLocation {
        if presentLocation.coordinate.longitude == 0.0 {
            return CLLocation(latitude: 0.0, longitude: 0.0)
        }
        
        return presentLocation
    }
    
    //MARK: Delegate method
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        presentLocation = locations[0]

    }

    
    private func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        
        switch status {
            
        case .denied:
            print("Permission Denied")
            break
        case .notDetermined:
            print("Permission Not Determined G")
            break
            
        default:
            print("\(presentLocation.coordinate.latitude)")
            print("\(presentLocation.coordinate.longitude)")
            break
        }
    }
    
}
